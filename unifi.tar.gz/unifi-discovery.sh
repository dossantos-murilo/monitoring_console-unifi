#!/bin/bash
# Script para descoberta de certa informacao e devolucao em formato JASON. Funciona para o Discovery zabbix na plataforma UniFi.


## Metadados:
#
# Autor: Werneck Costa - werneck.costa@gmail.com
# Versao atual: 0.0.2 / 25/04/15
#
# Editor: Werneck Costa.
# ChangeLog:
#        0.0.0 - 20/07/14: Análise dos dados fornecidos pela API e criação dos Scripts com informções básicas;
#        0.0.1 - 26/07/14: Edição dos scripts para dados mais refinados. Implementação no Zabbix;
#        0.0.2 - 25/04/15: Ajustes nos itens do Zabbix (itens acentuados).
#
## EOM

IFS=','

PYTHON="/usr/bin/python"
SCRIPT_ATUAL="$(basename $0)"
DIR_ATUAL="`echo $0|sed s/$SCRIPT_ATUAL//g`"
DIR_SCRIPTS_AUX="`echo $0|sed s/$SCRIPT_ATUAL//g`/ubiquiti"

aps(){
QTD="$($PYTHON $DIR_SCRIPTS_AUX/aps.py|cut -d ';' -f 3|wc -l)"

retorno=`echo "{\n\t"\"data\"":["`
for ap in $($PYTHON $DIR_SCRIPTS_AUX/aps.py|cut -d ';' -f 1,2,3|tr '\n' ',')
do
	ap_mac="$(echo $ap|cut -d ";" -f 3)"
	ap_nome="$(echo $ap|cut -d ";" -f 1)"
	ap_ip="$(echo $ap|cut -d ";" -f 2)"
        if [ "$QTD" -le "1" ]
        then
	unset IFS
        retorno=$retorno"$(echo "\n\t\t{\n\t\t\t\"{#AP_NOME}\":\"$ap_nome\",")"
	retorno=$retorno"$(echo "\n\t\t\t\"{#AP_MAC}\":\"$ap_mac\",")"
	retorno=$retorno"$(echo "\n\t\t\t\"{#AP_IP}\":\"$ap_ip\"}]}")"
        	else
                retorno=$retorno"$(echo "\n\t\t{\n\t\t\t\"{#AP_NOME}\":\"$ap_nome\",")"
		retorno=$retorno"$(echo "\n\t\t\t\"{#AP_MAC}\":\"$ap_mac\",")"
		retorno=$retorno"$(echo "\n\t\t\t\"{#AP_IP}\":\"$ap_ip\"},")"
        fi
        QTD=$(($QTD - 1))
done

retorno=$retorno"\n"
echo -e $retorno
}

wlans(){
#set -x
QTD="$($PYTHON $DIR_SCRIPTS_AUX/wlans.py|sort|uniq|wc -l)"

retorno=`echo "{\n\t"\"data\"":["`
for wlan in $($PYTHON $DIR_SCRIPTS_AUX/wlans.py|sort|uniq|cut -d ';' -f 1|tr '\n' ',')
do
        if [ "$QTD" -le "1" ]
        then
	unset IFS
        retorno=$retorno"$(echo "\n\t\t{\n\t\t\t\"{#WLAN_NOME}\":\"$wlan\"}]}")"
                else
                retorno=$retorno"$(echo "\n\t\t{\n\t\t\t\"{#WLAN_NOME}\":\"$wlan\"},")"
        fi
        QTD=$(($QTD - 1))
done

retorno=$retorno"\n"
echo -e $retorno
}

case "$1" in
        aps)
        aps
        ;;
        clients)
	echo "Implementação desnecessária. Não existe uma aplicação (ainda) que justifique o discovery de clientes."
	;;
        wlans)
	wlans
	;;
        *)
	echo "Comando nao reconhecido." 
	echo "Tente $0 [aps|clients|wlans]"
	;;
esac

unset IFS
