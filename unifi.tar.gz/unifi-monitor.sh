#!/bin/bash
#
# unifi-monitor.sh 
#
## Metadados:
#
# Autor: Werneck Costa - werneck.costa@gmail.com
# Versao atual: 0.0.2 / 25/04/15
#
# Editor: Werneck Costa.
# ChangeLog:
#        0.0.0 - 20/07/14: Análise dos dados fornecidos pela API e criação dos Scripts com informções básicas;
#        0.0.1 - 26/07/14: Edição dos scripts para dados mais refinados. Implementação no Zabbix;
#        0.0.2 - 25/04/15: Ajustes nos itens do Zabbix (itens acentuados).
#
# Script para obter dados de controladores Ubiquiti da linha UniFi (http://www.ubnt.com/enterprise/#unifi)
# Utiliza alguns Scripts em Python, provenientes de https://github.com/unifi-hackers/unifi-api/ (posterirmente migrado para https://github.com/calmh/unifi-api) para trazer dados de um controlador UniFi.
#
## Scripts auxiliares (executados pelo 'unifi-monitor.sh'):
# aps.py:
# Lista APs adodatos pelo Controlador no formato "Nome_AP;IP_AP;MAC_AP;Estado_AP"
# ---
#
# clients.py:
# Lista os clientes conectados em todos os SSIDs. Saida no formato "MAC_Client;SSID_Client;MAC-AP_Client"
# ---
#
# wlans.py:
# Lista todas as WLANS no formato 'Nome_WLAN;Estado_WLAN'
#
## Parametros de entrada:
# Como o script geral acessa três outros scripts, é importante saber de onde se deve buscar a informação e se existe algum filtro especifico.
#
# $tipo: 
# Revela o alvo da pesquisa. O retorno eh a lista de todos os itens do tipo $tipo.
# Aceitaveis: aps, clients, wlans
# Exemplo: 
# ./unifi-monitor.sh aps
# Resultado: lista com todos os APs já adotados pelo controlador (que podem ou não estar online no momendo da consulta)
#
# ---
#
# $filtro:
# Especifica um filtro adicional ao parametro $tipo.  Os filtros dependem de cada parametro. Alguns parametros possuem mais de um filtro.
# Aceitaveis: 
# 'total': retorna o total numérico relacionado ao parametro $tipo. 
# Ex: ./unifi-monitor.sh aps total -> retornará um valor numerico relacionado a soma da quantidade de APs
# Ex: ./unifi-monitor.sh clients total -> retornará um valor numérico relacionado a soma da quantidade de Clientes Wireless conectados
# Ex: ./unifi-monitor.sh wlans total -> retornara um valor numerico relacionado a soma da quantidade de SSIDs Wireless configurados
#
# 'lld': retorna uma lista, no formato JSON, a ser utilizado pelo Zabbix para LLD.
# Ex: ./unifi-monitor.sh aps lld -> retornará uma lista com os itens a serem utilizados no "Low Level Discovery" do Zabbix, facilitando a auto-configuração de novos APs. O mesmo serve para WLANs (SSIDs).
# Obs: A descoberta para clients não está ativada, pois
#
# ---
## EOM

# Variaveis:
PYTHON="/usr/bin/python"
SCRIPT_ATUAL="$(basename $0)"
DIR_ATUAL="`echo $0|sed s/$SCRIPT_ATUAL//g`"
DIR_SCRIPTS_AUX="`echo $0|sed s/$SCRIPT_ATUAL//g`/ubiquiti"
TIPO="$1"
FILTRO="$2"
PARAM="$3"

aps(){
	if [ "x$1" == "x" ]
	then
	$PYTHON $DIR_SCRIPTS_AUX/aps.py
	else	
	
		case "$1" in
			total)
			echo `$PYTHON $DIR_SCRIPTS_AUX/aps.py|wc -l`	
			;;
			total-active)
			echo `$PYTHON $DIR_SCRIPTS_AUX/aps.py|grep -v "None"|wc -l`
			;;
			active)
                        $PYTHON $DIR_SCRIPTS_AUX/aps.py|grep -v "None"
			;;
			lld)
			$DIR_ATUAL/unifi-discovery.sh aps
			;;
			*)
			echo "Parametro desconhecido ou inexistente: $*"
			exit 1
			;;
		esac
	fi
}

clients(){
        if [ "x$1" == "x" ]
        then
        $PYTHON $DIR_SCRIPTS_AUX/clients.py
        else

                case "$1" in
                        total)
                        echo `$PYTHON $DIR_SCRIPTS_AUX/clients.py|sort|uniq|wc -l`
                        ;;
			by-ap)
			echo `$PYTHON $DIR_SCRIPTS_AUX/clients.py|cut -d ';' -f 3|sort|grep "$2"|wc -l`
			;;
			by-ssid)
			echo `$PYTHON $DIR_SCRIPTS_AUX/clients.py|cut -d ';' -f 2|sort|grep "$2"|wc -l`
                        ;;
			*)
                        echo "Parametro desconhecido ou inexistente: $*"
                        exit 1
                        ;;
                esac
        fi

}

wlans(){
        if [ "x$1" == "x" ]
        then
        $PYTHON $DIR_SCRIPTS_AUX/wlans.py|sort|uniq|sed 's/True/Ativo/g'|sed 's/False/Inativo/g'
        else

                case "$1" in
                        total)
                        echo `$PYTHON $DIR_SCRIPTS_AUX/wlans.py|sort|uniq|wc -l`
                        ;;
			lld)
                        $DIR_ATUAL/unifi-discovery.sh wlans
                        ;;
                        *)
                        echo "Parametro desconhecido ou inexistente: $*"
                        exit 1
                        ;;
                esac
        fi

}

case "$TIPO" in
	aps) 
		aps $FILTRO $PARAM
	;;
	
	clients)
		IFS=","
		clients $FILTRO $PARAM
		unset IFS
	;;

	wlans)
		wlans $FILTRO $PARAM
	;;

	*)
	echo "É preciso informar ao menos um parametro! -> aps | clients | wlans"
	exit 1	
esac
