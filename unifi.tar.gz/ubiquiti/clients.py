"""
 clients.py

 Autor: Werneck Costa - werneck.costa@gmail.com
 Versao atual: 0.0.2 / 25/04/15

 Editor: Werneck Costa.
 ChangeLog:
        0.0.0 - 20/07/14: Analise dos dados fornecidos pela API e criacao dos Scripts com informacoes basicas;
        0.0.1 - 26/07/14: Edicao dos scripts para dados mais refinados. Implementacao no Zabbix;
        0.0.2 - 25/04/15: Ajustes nos itens do Zabbix (itens acentuados).
 
 - Tarefas: 
 -> Trazer a lista completa de clientes.

Formato de saida: 'MAC_Client;SSID_Client;MAC-AP_Client'
"""

from unifi.controller import Controller

c = Controller('endereco-controlador-unifi', 'Usuario', 'Senha', 'v3', 'Site')

for client in c.get_clients():
	print '%s;%s;%s' % (client['mac'], client['essid'], client['ap_mac'])
