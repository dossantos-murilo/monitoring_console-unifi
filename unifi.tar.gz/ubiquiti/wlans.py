#!/usr/bin/python

"""
 wlans.py

 Autor: Werneck Costa - werneck.costa@gmail.com
 Versao atual: 0.0.2 / 25/04/15

 Editor: Werneck Costa.
 ChangeLog:
        0.0.0 - 20/07/14: Analise dos dados fornecidos pela API e criacao dos Scripts com informacoes basicas;
        0.0.1 - 26/07/14: Edicao dos scripts para dados mais refinados. Implementacao no Zabbix;
        0.0.2 - 25/04/15: Ajustes nos itens do Zabbix (itens acentuados).
 
 - Tarefas: 
 -> Trazer todas as informacoes sobre os SSIDs.

Formato de saida: "Nome_SSID;Status"
"""

from unifi.controller import Controller

c = Controller('endereco-controlador-unifi', 'Usuario', 'Senha', 'v3', 'Site')

for wlan in c.get_wlan_conf():
 print '%s;%s' % (wlan['name'], wlan['enabled'])

