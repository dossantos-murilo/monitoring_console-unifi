"""
 aps.py
 
 Autor: Werneck Costa - werneck.costa@gmail.com
 Versao atual: 0.0.2 / 25/04/15


 Editor: Werneck Costa.
 ChangeLog:
	0.0.0 - 20/07/14: Analise dos dados fornecidos pela API e criacao dos Scripts com informacoes basicas;
	0.0.1 - 26/07/14: Edicao dos scripts para dados mais refinados. Implementacao no Zabbix;
	0.0.2 - 25/04/15: Ajustes nos itens do Zabbix (itens acentuados). 
 

 - Tarefas: 
 -> Trazer a lista completa de APs;

Formato de saida: 'Nome_AP;IP_AP;MAC_AP;Estado_AP'
"""

from unifi.controller import Controller

c = Controller('endereco-controlador-unifi', 'Usuario', 'Senha', 'v3', 'Site')

for ap in c.get_aps():
 print '%s;%s;%s;%s' % (ap['name'], ap['ip'], ap['mac'], ap.get('state'))
